var searchData=
[
  ['distance',['distance',['../classCoarsing.html#accc475e5888ec7a03a26b2354716a41d',1,'Coarsing']]]
];
