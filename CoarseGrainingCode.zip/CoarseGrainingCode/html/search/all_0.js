var searchData=
[
  ['cgp',['CGP',['../classCoarsing.html#a17b179f56085f3f9a172e4591fc21a2b',1,'Coarsing']]],
  ['cgpoint',['CGPoint',['../classCGPoint.html',1,'']]],
  ['coarsing',['Coarsing',['../classCoarsing.html',1,'']]],
  ['compute_5flpq',['compute_lpq',['../structData.html#aba0bdd673b8a3d0401deb7da3e479735',1,'Data']]],
  ['ct',['cT',['../classCoarsing.html#a820ee3cdc5a2f3a10fdfb295abd72f9a',1,'Coarsing']]],
  ['cutoff',['cutoff',['../classCoarsing.html#a1cc37fdd5e18d1a53c4d3e60be2b3c43',1,'Coarsing']]]
];
