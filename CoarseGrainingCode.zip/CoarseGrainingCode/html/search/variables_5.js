var searchData=
[
  ['rot_5ffluc',['rot_fluc',['../structData.html#ac752e81ef5cfd30eb36d0135ddc3ce9c',1,'Data']]]
];
