var searchData=
[
  ['d',['d',['../classCoarsing.html#a88086b32fb8eb340560c00ad3f132937',1,'Coarsing']]],
  ['data',['Data',['../structData.html',1,'']]],
  ['distance',['distance',['../classCoarsing.html#accc475e5888ec7a03a26b2354716a41d',1,'Coarsing']]]
];
