var searchData=
[
  ['time',['Time',['../classCoarsing.html#a49f5477a50665dabd7c8d6ee05fbfb89',1,'Coarsing']]]
];
