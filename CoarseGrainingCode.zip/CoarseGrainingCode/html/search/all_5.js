var searchData=
[
  ['pass_5f1',['pass_1',['../classCoarsing.html#a41a64f445a65ae8fa6355cf75e095779',1,'Coarsing']]],
  ['pass_5f2',['pass_2',['../classCoarsing.html#a0556e88442645cf2def6f9ce918b9bb3',1,'Coarsing']]],
  ['pass_5f3',['pass_3',['../classCoarsing.html#ac2ae89b569d5d21ff2f54798021d366a',1,'Coarsing']]]
];
