var searchData=
[
  ['location',['location',['../classCGPoint.html#a8b3032ef9cfc6f32d1cab9aa912ce82d',1,'CGPoint']]]
];
