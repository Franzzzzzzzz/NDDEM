var searchData=
[
  ['random_5ftest',['random_test',['../structData.html#a52baee43793f5f03088eb32a36f4c6fb',1,'Data']]],
  ['rot_5ffluc',['rot_fluc',['../structData.html#ac752e81ef5cfd30eb36d0135ddc3ce9c',1,'Data']]]
];
