var searchData=
[
  ['window',['window',['../classCoarsing.html#ae58a2ff869a21d6590983c47f45c302f',1,'Coarsing']]],
  ['window_5fint',['window_int',['../classCoarsing.html#a9e816e036f21344f6cbce59f915a378c',1,'Coarsing::window_int(v1d r1, v1d lpq, v1d x)'],['../classCoarsing.html#a592f32474e5d1780964dbc963590b888',1,'Coarsing::window_int(double r1, double r2)']]]
];
