var searchData=
[
  ['compute_5flpq',['compute_lpq',['../structData.html#aba0bdd673b8a3d0401deb7da3e479735',1,'Data']]]
];
