var searchData=
[
  ['fidx',['Fidx',['../classCoarsing.html#a07ec285bd11033d10f7a27a38bd5fd62',1,'Coarsing']]],
  ['fields',['fields',['../classCGPoint.html#ad0fd06c53bc917bdf91abbbdb4b8e4c3',1,'CGPoint::fields()'],['../classCoarsing.html#aa2fe878237d61cfea5421bd433e1210d',1,'Coarsing::Fields()'],['../classCoarsing.html#a56e5de2d000122cd6054017025e9634b',1,'Coarsing::FIELDS()']]],
  ['flags',['flags',['../classCoarsing.html#a71f3970db217286403591f34bd51c2da',1,'Coarsing']]]
];
