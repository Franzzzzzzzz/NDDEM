var searchData=
[
  ['cgpoint',['CGPoint',['../classCGPoint.html',1,'']]],
  ['coarsing',['Coarsing',['../classCoarsing.html',1,'']]]
];
