


#ifndef TYPEDEFS
#define TYPEDEFS
using namespace std ;
using v1d = vector < double > ;
using v1i = vector <int> ; 
using v2d = vector < vector <double> > ;
using cv1d= const vector <double> ; 
using cv2d= const vector < vector <double> > ; 
#endif
